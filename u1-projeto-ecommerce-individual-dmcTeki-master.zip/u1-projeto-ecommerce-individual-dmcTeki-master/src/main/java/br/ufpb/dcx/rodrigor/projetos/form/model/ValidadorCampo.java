package br.ufpb.dcx.rodrigor.projetos.form.model;

public interface ValidadorCampo {
    ResultadoValidacao validarCampo(String valor);
}
