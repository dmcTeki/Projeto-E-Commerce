package br.ufpb.dcx.rodrigor.projetos.form.model;

public interface PersistenciaFormulario {

    void persistir(Formulario formulario);
}
