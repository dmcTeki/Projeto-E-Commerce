package br.ufpb.dcx.rodrigor.projetos;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class AtividadeTest {



    @Test
    void testSomething() {
        assertEquals("teste","teste");

    }
}
